package com.example.myapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "login_prefs";
    private static final String KEY_REMEMBERED = "remembered";
    private static final String KEY_USERNAME = "username";

    private EditText etUsername, etPassword;
    private TextView tvMessage;
    private CheckBox cbShowPassword, cbRememberMe;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 1) If remembered, skip login screen
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        boolean remembered = prefs.getBoolean(KEY_REMEMBERED, false);
        if (remembered) {
            String savedUser = prefs.getString(KEY_USERNAME, "User");
            goToWelcome(savedUser);
            finish();
            return;
        }

        // 2) Normal login UI
        setContentView(R.layout.activity_main);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        tvMessage = findViewById(R.id.tvMessage);
        cbShowPassword = findViewById(R.id.cbShowPassword);
        cbRememberMe = findViewById(R.id.cbRememberMe);

        Button btnLogin = findViewById(R.id.btnLogin);
        Button btnCancel = findViewById(R.id.btnCancel);

        // 3) Show/Hide password toggle
        cbShowPassword.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                etPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
            } else {
                etPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            }
            etPassword.setSelection(etPassword.getText().length()); // keep cursor at end
        });
        Button btnGoRegister = findViewById(R.id.btnGoRegister);
        btnGoRegister.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
            startActivity(intent);
        });

        // 4) Login button logic
        btnLogin.setOnClickListener(v -> {
            String user = etUsername.getText().toString().trim();
            String pass = etPassword.getText().toString().trim();

            // Empty fields validation
            if (user.isEmpty() || pass.isEmpty()) {
                tvMessage.setText("Please enter both username and password.");
                return;
            }

            // Hardcoded validation

            String savedUser = prefs.getString("username", "");
            String savedPass = prefs.getString("password", "");

            boolean isAdmin =
                    user.equals("admin") && pass.equals("1234");

            boolean isRegisteredUser =
                    user.equals(savedUser) && pass.equals(savedPass);

            if (isAdmin || isRegisteredUser) {
                tvMessage.setText("Login Successful");

                if (cbRememberMe.isChecked()) {
                    prefs.edit()
                            .putBoolean("remembered", true)
                            .putString("username", user)
                            .apply();
                }

                goToWelcome(user);
            } else {
                tvMessage.setText("Invalid username/password.");
            }
        });

        // 5) Cancel button clears fields + message
        btnCancel.setOnClickListener(v -> {
            etUsername.setText("");
            etPassword.setText("");
            tvMessage.setText("");
            cbShowPassword.setChecked(false);
            cbRememberMe.setChecked(false);
        });
    }

    private void goToWelcome(String username) {
        Intent intent = new Intent(MainActivity.this, WelcomeActivity.class);
        intent.putExtra("username", username);
        startActivity(intent);
    }
}
