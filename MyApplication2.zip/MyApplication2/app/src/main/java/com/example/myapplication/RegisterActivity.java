package com.example.myapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        EditText etUser = findViewById(R.id.etRegUsername);
        EditText etPass = findViewById(R.id.etRegPassword);
        TextView tvMsg = findViewById(R.id.tvRegMessage);
        Button btnRegister = findViewById(R.id.btnRegister);

        btnRegister.setOnClickListener(v -> {
            String user = etUser.getText().toString().trim();
            String pass = etPass.getText().toString().trim();

            if (user.isEmpty() || pass.isEmpty()) {
                tvMsg.setText("Please fill all fields.");
                return;
            }

            SharedPreferences prefs =
                    getSharedPreferences("login_prefs", MODE_PRIVATE);

            prefs.edit()
                    .putString("username", user)
                    .putString("password", pass)
                    .apply();

            tvMsg.setText("Registration successful!");

            // Go back to login screen
            Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        });
    }
}
